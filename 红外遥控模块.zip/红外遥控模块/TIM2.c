#include "stm32f10x.h"                  // Device header
                 // Device header
#include "red_control.h"
#include "string.h"


void TIM2_Init()
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_TimeBaseInitStruct.TIM_ClockDivision= TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode=TIM_CounterMode_Up ;
	TIM_TimeBaseInitStruct.TIM_Period= 0xFFFF;
	TIM_TimeBaseInitStruct.TIM_Prescaler= 71;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseInitStruct);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	NVIC_EnableIRQ(TIM2_IRQn);
	
}

//void TIM2_IRQHandler()
//{
//	STOP_COUNT();
//	nec.cnt=0;
//	
//	nec.NEC_TRIGGER_CNT=0;
//	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
//}