#ifndef _TIM2_H
#define _TIM2_H
#include "stm32f10x.h"                  // Device header



void TIM2_Init();

#define START_COUNT()    do{TIM2->CNT =0;TIM_Cmd(TIM2,ENABLE);}while(0)
#define STOP_COUNT()     TIM_Cmd(TIM2,DISABLE)
#define GET_COUNT()        TIM2->CNT


#endif
